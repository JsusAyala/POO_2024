from conexionBd import *
import os

class cliente:
    def __init__(self, id, nombre, apellido, email, telefono, direccion):
        self.id = id 
        self.nombre = nombre
        self.apellido = apellido
        self.email = email
        self.telefono = telefono
        self.direccion = direccion

    def crear(self):
        try:
            sql="INSERT INTO cliente VALUES (NULL, %s, %s, %s, %s, %s)"
            valor=(self.nombre, self.apellido, self.email, self.telefono, self.direccion)
            cursor.execute(sql,valor)
            conexion.commit()
            print("El cliente a sido creado exitosamente")
            return True
        except Exception as e:
            print(f"Error al crear el cliente: {e}")
            return False
          
    @staticmethod              
    def mostrar():
        try:
            id=(input("Ingrese el id del cliente: "),)
            cursor.execute(
                "select * from cliente where id=%s ",id
            )
            return cursor.fetchall()
        except:
            return []
        
    @staticmethod       
    def actualizar():
        try:
            os.system
            id=input("Ingrese eo ID de cliente: ")
            nombre=input("ingrese su nombre: ") 
            apellido=input("Ingrese su apellido: ")
            email=input("Ingrese su  email: ")
            telefono=input("Ingrese su numero de telefono: ")
            direccion=input("ingrese su direccion: ")
            sql="update cliente set nombre=%s,apellido=%s,email=%s,telefono=%s,direccion=%s where id=%s"
            cursor.execute(sql,(nombre,apellido,email,telefono,direccion,id))
            conexion.commit()
            print("Se actualizo con exito")
            esperarTecla()
            os.system
            return True
        except:
    
            return False
        
    @staticmethod
    def eliminar(id):
        try:
          cursor.execute(
            "delete from cliente where id=%s",
            (id,)
          ) 
          conexion.commit() 
          return True  
        except:    
          return False
        
def esperarTecla():
  print("\n \t \tDa click en cualquier tecla para continuar ...")
  input() 