from Clases.funciones import *
import os 

def menuPrincipal():
            os.system("cls")
            print("...::Clientes::...")
            print(" 1. Añadir un cliente\n 2. Mostrar clientes \n 3. Actualizar clientes \n 4. Eliminar clientes \n 5. Salir")
            opcion=input("Seleccione una opción: ")
            if opcion=='1':
                os.system("cls")
                print("...::Añadir un cliente::...")
                nombre=input("Ingrese su nombre: ") 
                apellido=input("Ingrese su apellido: ")
                email=input("Ingrese su email: ")
                telefono=input("Ingrese su número de teléfono: ")
                direccion=input("Ingrese su dirección: ")
                objetocliente=cliente(id, nombre, apellido, email, telefono, direccion)
                objetocliente.crear()
                esperarTecla()
                os.system("cls")
            elif opcion=='2':
                os.system("cls")
                print("..::Mostrar clientes::..")
                resultados = cliente.mostrar()
                if resultados:
                    for resultado in resultados:
                        print(f" ID: {resultado[0]}\n Nombre: {resultado[1]}\n Apellido: {resultado[2]}\n Email: {resultado[3]}\n Teléfono: {resultado[4]}\n Dirección: {resultado[5]}")
                else:
                    print("No se encontró ningún cliente con ese ID.")
                esperarTecla()
                os.system("cls")
            elif opcion=='3':
                cliente.actualizar()
            elif opcion=='4':
                id = input("\t \t ID del cliente a eliminar: ")
                resultado=cliente.eliminar(id)
                if resultado:
                    print(f"\n \t \t.::Cliente Eliminado Correctamente ::.")
                else:
                    print(f"\n \t \t** No fue posible eliminar al cliente ... vuelva a intentarlo **...")  
                esperarTecla()
            elif opcion=='5':
                exit
            else:
                print("\n \t \t Opción no válida. Intenta de nuevo.")
                esperarTecla()
